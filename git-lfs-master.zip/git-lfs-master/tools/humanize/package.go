// package humanize is designed to parse and format "humanized" versions of
// numbers with units.
//
// Based on: github.com/dustin/go-humanize.
package humanize
